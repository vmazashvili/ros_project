Note: the player/stage files are all taken from the player and stage
distribution at
```
($STAGE)/share/stage/worlds/  and 
($PLAYER)/share/player/examples/libplayer* 
```
They are just copied here for your convienence.
