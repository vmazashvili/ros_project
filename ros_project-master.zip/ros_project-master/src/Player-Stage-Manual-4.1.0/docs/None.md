[Redirect to patch RTD menu](http://player-stage-manual.readthedocs.org/en/stable)
